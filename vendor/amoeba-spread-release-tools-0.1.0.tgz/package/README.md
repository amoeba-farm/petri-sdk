# Ameba Spread

Ameba Spread is the Solana program and client surface for fully collateralized
memory-component forward contracts, governed oracle formation, current cash
workflows, and native in-program secondary liquidity.

Program id:

```text
9ipkBCjEfeJDMF6AFrezRmDDHmbnmeyv45cfXNqAnWsH
```

## Current Devnet phase

The program ID is upgraded in place, but protocol state starts fresh under the
`ameba-spread-v2` namespace. Existing accounts outside that namespace are not
loaded or rewritten. Removed instruction bytes have no typed variant or handler
and fail through the generic invalid-instruction path.

The release uses one stripped final artifact. ProgramData capacity is computed
from that artifact alone; there is no intermediate deployment or state transfer.
After the upgrade, governance initializes a new paused config, new collateral
and token identities, a new signer registry, new oracle economics, and the first
rolling-ladder state.

The maintained plan/execute/verify workflow and canonical receipt contract are
documented in [the Devnet V2 bootstrap guide](docs/devnet_v2_bootstrap.md).

## Rolling three-month ladder

Each monthly Scramble creates only the newly entering far-month contract:

```text
January:   JAN — FEB — MAR
February:        FEB — MAR — APR
March:                 MAR — APR — MAY
```

The two already-live months keep their frozen recipes. Planned listing is the
first UTC calendar day at the protocol roll time; expiry is exactly three
calendar months later at that same time. The maturity registry advances one
month at a time and rejects skips, backtracking, or staging a second future rung.
The JAN/FEB/MAR labels above are maturity labels for the last live calendar
month, so JAN expires at the February boundary; JAN's planned listing was the
prior November boundary.

The fresh 2026 Devnet state seeds the exact current leading curve, oldest first:

| Maturity | Scramble | Planned listing | Immutable expiry |
| --- | --- | --- | --- |
| NOV | 2026-08-24 00:00 UTC | 2026-09-01 00:00 UTC | 2026-12-01 00:00 UTC |
| DEC | 2026-09-23 00:00 UTC | 2026-10-01 00:00 UTC | 2027-01-01 00:00 UTC |
| JAN | 2026-10-24 00:00 UTC | 2026-11-01 00:00 UTC | 2027-02-01 00:00 UTC |

These are new current-protocol rungs. No earlier market or bootstrap state is
adopted. The bootstrap receipt must prove all three rungs and prove that no
fourth rung was created.

## Governed SKU identity and full coverage

Product manifests contain the exact terminal SKU identifiers, not only a count.
Governance submits them in ordered chunks of at most 16 identifiers; only the
complete strictly ascending, nonzero, unique set can create the immutable
product manifest.

RAMX v1 contains 52 governed SKUs. Its encoded Merkle root is:

```text
52a574e7fee12f9921b3b220b709be16c13a6f290abbdc2cc203ed1191ecf578
```

The packet-safe submission plan is `16/16/16/4`.

NANDX v1 contains 48 governed terminal MPNs. Its encoded Merkle root is:

```text
41bb5dc79bacabb3e0876b55e647b01084c7fe8b39846fd707ee0fd973d28c3d
```

Its submission plan is `16/16/16`. The separate governed benchmark basket has
22 rows whose fixed weights total exactly 100%; 18 rows are item-addressable and
four raw-wafer rows are assessment-only. Terminal identities aggregate inside
their parent basket row before that row's fixed product weight is applied.

Every monthly source set is fail-closed on coverage:

- source submission remains open until every frozen SKU has a surviving,
  nonzero-supported source;
- on-time completion leaves the calendar unchanged;
- late completion moves only effective listing and preserves the complete
  Challenge, Resolution, and Opening windows;
- expiry never moves;
- losing the last source for a SKU removes coverage and reopens submission;
- weights, Opening, Game, market unpause, and issuance require the exact
  finalized coverage manifest.

Within each governed SKU bucket, admitted sources have equal standing. The
program takes a deterministic median of per-source percentage deltas; support
cash is used only for admission, challenge exposure, and rewards and never for
index composition. Final settlement first takes each source's temporal median
from the five-business-day expiry window, then takes the cross-source bucket
median. A one-time five-business-day lookback extension and sAMBA emergency
default handle insufficient fresh coverage without silently settling a thin
set.

Collective-enabled series issue only through a funded sleeve auction after the
canonical settlement group, complete coverage, active weights, sealed policy,
and exact reserve checks all pass. Accepted buyer premium enters the dedicated
sleeve vault atomically with external-OI growth and delivery of the canonical
claim. The native DLMM remains a secondary venue and cannot create supply.

## Current economics

Oracle cash rewards are finite classic-SPL collateral deposited before schedule
reservation. Ordinary source, opening, and update challenges are participant-
funded zero-sum contests. Claims use exact current typed accounts; stale cleanup
changes state and releases locks but never transfers principal.

Fresh settlement-window updates receive three reward units. Half of recorded
USDC DLMM protocol fees is isolated for per-bucket update bounties and assigned
by immutable product bucket weight after settlement. Aggregate sleeve external
exposure is capped by the canonical oracle-security budget; premium funding is
never subtracted from oracle attack exposure.

The collective cutover keeps exact-size ProgramData allocation and ratifies a
`1,300,000`-byte release ceiling inside a modeled core-rent ceiling of two
thirds of the frozen pre-compression baseline. The release checker derives and
enforces the tighter of those limits; deployments reserve no speculative
capacity.

Emergency disputes use escrowed sAMBA only. Supermajority, commit window, and
reveal window are frozen from the current economics template. Decisive
outcomes redistribute the losing/nonreveal pot to the winning voters; failed
consensus refunds all voters.

## Settlement and liquidity

Settlement publication derives the recipe and final-source digests from current
on-chain manifests and verifies the active immutable signer set. The signed
settlement timestamp must equal the market's on-chain expiry. Settlement and
liquidity cleanup become eligible at `expiry + 7,200` seconds.

Trading uses the program-owned finite additive-grid Amoeba DLMM. Every market
binds one canonical long-contract/USDC pool; V1 liquidity is manager-only, while
traders have protected exact-input buys and sells. Pool, page, and position
state use Light's hot/cold lifecycle, and canonical Light Token vault balances
are checked against program accounting after every transfer. Final settlement
irreversibly disables swaps while leaving managed liquidity removal and fee
collection available before terminal closure.

Each initial contract represents one underlying index unit
(`contractSizeScale = 6`, `contractSizeAtomic = 1_000_000`), and premiums are
quoted in USDC per contract. The neutral call/put pair uses the same 12% width
and maximum payout. Its native quote grid advances by `50_000` USDC atoms
($0.05), ends at bin 240 ($12.00), and creates only the pages needed by active
liquidity. Premium references in the catalog seed liquidity management; they
are not immutable market fields.

## Repository layout

- `programs/light_token_minter/` — Solana program and Rust tests
- `clients/ts/` — TypeScript instruction builders, planners, and tests
- `governance/ramx_product_sku_manifest.v1.json` — governed RAMX source manifest
- `governance/nandx_product_sku_manifest.v1.json` — governed NANDX terminal MPNs
- `governance/nandx_benchmark_basket.v1.json` — fixed NANDX product basket
- `config/options_catalog.json` — client catalog and parity data
- `release/intents/v0.1.0-devnet.json` — tracked final-only release policy
- `deployments/devnet.json` — deployment identity and blocked/verified status
- `docs/amoeba_oracle_timed_dlmm_provisioning.md` — oracle and DLMM operator flow
- `docs/amoeba_staking.md` — AMBA/sAMBA behavior
- `docs/writer_issuance_settlement_spec.md` — issuance and settlement contract

## Build and test

On this Windows desktop, use WSL `Ubuntu-22.04` for Solana builds:

```bash
export PATH="$HOME/.cargo/bin:$HOME/.local/share/solana/install/active_release/bin:$PATH"
cd /mnt/c/path/to/ameba_spread/programs/light_token_minter
cargo fmt --all -- --check
cargo test --all-targets
cargo-build-sbf
```

TypeScript checks:

```bash
cd clients/ts
npm run typecheck
npm test
```

Release checks:

```bash
python scripts/check_release_candidate.py
python scripts/check_deployment_manifests.py
python scripts/check_public_source_export.py
```

The release build is run twice. Both final artifacts must have identical byte
length and SHA-256 before any ProgramData sizing or upgrade authorization.

## Deployment rule

Passing source tests does not authorize deployment. A Devnet upgrade additionally
requires the exact final build receipt, live finalized ProgramData/authority and
feature evidence, a finalized full-account compatibility census, an exact
zero-headroom capacity plan, signer availability, and
post-upgrade verification that deployed ProgramData hashes to the attested final
artifact and that the compatible current account inventory is unchanged.

Unexpired current markets do not require a legacy lane. A code-only upgrade may
retain them only when each Market is paused with zero collateral and zero
outstanding contracts and each existing OracleMonth is still pre-activity with
empty coverage. The same exact 299-byte OracleMonth layout and current execution
path then serve those markets and every future market. Any unsupported account,
started weighting state, or economic activity blocks the upgrade.
