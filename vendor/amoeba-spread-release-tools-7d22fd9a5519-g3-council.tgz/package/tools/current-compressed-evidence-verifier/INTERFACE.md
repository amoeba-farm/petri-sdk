# Current compressed evidence verifier v1

Local pre-test candidate. This helper has no network, signing or
transaction interface. The authorized Linux release build is unqualified;
consumers must configure an absolute trusted path and independently pinned SHA256.
Never accept either value from Photon or from an evidence request.

The native npm package exports `./compressed-evidence-verifier-source` as the
`source.json` locator alongside an explicit source/Cargo/interface file allowlist.
Consumers can resolve that export and locate the Cargo manifest relative to it.
The lockfile retains the dependency records/checksums from the program lock and
adds this standalone root package. The local build resolved/pruned the standalone
lock offline without adding package versions or changing source checksums.
The separate local build receipt records the executable path and SHA256; proof
fixtures and executable qualification remain deferred. No installer executes Cargo
or compiles the helper.

One UTF-8 JSON document on stdin, EOF terminated; one JSON document on stdout.
Maximum input 64 MiB, maximum individual decoded account 16 MiB. Run with an
argument-safe process API, empty arguments, bounded output and timeout. A nonzero
exit, malformed output, unexpected field, or mismatched binding rejects evidence.
No fallback to provider assertions is authoritative.

```ts
type RequestV1 = {
  schema: 'ameba-compressed-evidence-v1';
  finalizedSlot: string; // canonical decimal u64 from one finalized RPC response
  minimumSlot: string; // canonical decimal u64, includes Photon and read floors
  contextBindingHex: string; // lowercase 32-byte SHA256 of consumer identity context
  identity: {
    programIdHex: string; addressTreeKeyHex: string;
    canonicalPdaHex: string; domain: number; // exact current domain 1..10
  };
  compressedAccount?: { // REQUIRED for state modes, absent for address_absent
    ownerHex: string; addressHex: string; lamports: string;
    discriminatorHex: string; // 8 bytes, current CompressedAmebaStateLeaf
    dataHex: string; // COMPLETE 46-byte envelope + compact payload
    dataHashHex: string; // provider value compared with native SHA256BE recomputation
  };
  statement: {
    kind: 'state_merkle' | 'state_queue' | 'address_absent';
    treeKeyHex: string; // all hex is lowercase, no 0x
    queueKeyHex?: string; // required for state; absent for address (embedded queue)
    valueHex: string; // independently computed leaf hash OR derived address, 32 bytes
    leafIndex?: string; // required for state, canonical decimal u32
    rootHex?: string; // required only for Merkle/absence, 32 bytes
    rootIndex?: number; // required only for Merkle/absence, u16
    proofHex?: string; // required only for Merkle/absence, A32+B64+C32 bytes
  };
  accounts: Array<{
    keyHex: string; ownerHex: string; executable: boolean; dataHex: string;
  }>; // exactly tree+queue for state, exactly tree for address
};
type ResultV1 = {
  schema: 'ameba-compressed-evidence-v1';
  requestSha256: string; // SHA256 of EXACT stdin bytes, including any newline
  contextBindingHex: string;
  finalizedSlot: string;
  kind: RequestV1['statement']['kind'];
  valueHex: string;
  compressedAddressHex: string; // independently derived by the helper
  dataHashHex: string | null; // independently recomputed by the helper
  treeKeyHex: string;
  queueKeyHex: string | null;
  rootHex: string | null;
  rootIndex: number | null;
  verification: 'groth16_current_root_and_bloom' | 'queue_inclusion_and_bloom';
};
```

Consumer responsibilities: obtain raw tree and queue accounts in ONE standard-RPC
`getMultipleAccountsInfoAndContext` finalized response at `minContextSlot`; bind
that context slot without relabeling older snapshots. Validate canonical release
topology and Devnet genesis. Independently derive the namespace/domain/PDA/Light
address, decode and authenticate the program-owned leaf envelope, and recompute
the complete Light leaf hash using the helper's pinned native primitive, including
owner, address, data, lamports, tree and leaf index. Bind these identity inputs,
original Photon witness and payload bytes
in `contextBindingHex`; compare every result field and the exact request digest.
The helper independently derives the Light address from the exact current seeds,
checks envelope schema/domain/PDA/length, derives the type discriminator, recomputes
SHA256(data) with byte zero cleared, and calls pinned CompressedAccount::hash with
is_batched=true for BOTH state modes. It requires zero lamports and owner equal to
identity.programIdHex, and compares the recomputed full leaf hash to valueHex. It
does not derive business PDAs from market/month/owner inputs or attest RPC provenance.
Lean must independently construct these
bindings and invoke the trusted verifier; an arbitrary `verified:true` field or a
copied SDK result is not an independent check.

Native semantics: exact compression-program owner, non-executable accounts, unique
inventory, pinned discriminators and V2 tree/queue types, dimensions 32/40, exact
decoded account length and state tree/output queue association. For state Merkle
membership the leaf index must be below the tree insertion cursor. For queue
membership the current output queue value at that exact index must equal the
leaf hash (spent zeroes fail). Every statement checks the embedded tree input
queue bloom filters for non-inclusion of the leaf hash/address. Bloom positives
reject conservatively, including false positives. Merkle statements require the
CURRENT root and its current ring index in the finalized snapshot, not a historic
root that may predate a spend/address insertion. This intentionally narrower read
contract prevents stale history from authorizing a current bounty projection.

Single-statement V2 public input is Poseidon(root, leaf-hash/address), using
`light-hasher 5.0.0` two-input hash-chain primitive. Compressed proof decompression,
verification keys and Groth16 verification use `light-verifier 10.0.0` with exactly
(1 leaf, 0 addresses) or (0 leaves, 1 address). Queue mode requires no proof and
does not claim Groth16 verification. Decoders and nonmutating queue/bloom checks
use `light-batched-merkle-tree 0.11.0`, as pinned by the program Cargo lock.

This source does not provide enumeration completeness: consumers must still bind
the full owner/receipt/lineage inventory and fail closed on missing observations.
No helper build or proof execution is authorized in this pre-test pass.
