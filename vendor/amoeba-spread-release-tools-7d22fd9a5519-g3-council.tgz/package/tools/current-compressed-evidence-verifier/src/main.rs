//! Read-only, single-statement verifier. See ../INTERFACE.md for trust boundaries.
use std::io::{Read, Write};

use light_batched_merkle_tree::{
    constants::ACCOUNT_COMPRESSION_PROGRAM_ID,
    merkle_tree::BatchedMerkleTreeAccount,
    queue::{get_output_queue_account_size, BatchedQueueAccount},
    queue_batch_metadata::QueueBatches,
};
use light_compressed_account::{
    compressed_account::{CompressedAccount, CompressedAccountData},
    pubkey::Pubkey,
};
use light_hasher::hash_chain::create_two_inputs_hash_chain;
use light_verifier::{select_verifying_key, verify, CompressedProof};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

const SCHEMA: &str = "ameba-compressed-evidence-v1";
const MAX_INPUT: usize = 64 * 1024 * 1024;
const MAX_ACCOUNT: usize = 16 * 1024 * 1024;
type Checked<T> = Result<T, String>;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Request {
    schema: String,
    finalized_slot: String,
    minimum_slot: String,
    context_binding_hex: String,
    identity: Identity,
    compressed_account: Option<LeafAccount>,
    statement: Statement,
    accounts: Vec<Account>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Identity {
    program_id_hex: String,
    address_tree_key_hex: String,
    canonical_pda_hex: String,
    domain: u8,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct LeafAccount {
    owner_hex: String,
    address_hex: String,
    lamports: String,
    discriminator_hex: String,
    data_hex: String,
    data_hash_hex: String,
}

#[derive(Clone, Copy, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "snake_case")]
enum Kind {
    StateMerkle,
    StateQueue,
    AddressAbsent,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Statement {
    kind: Kind,
    tree_key_hex: String,
    queue_key_hex: Option<String>,
    value_hex: String,
    leaf_index: Option<String>,
    root_hex: Option<String>,
    root_index: Option<u16>,
    proof_hex: Option<String>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Account {
    key_hex: String,
    owner_hex: String,
    executable: bool,
    data_hex: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct Verified {
    schema: &'static str,
    request_sha256: String,
    context_binding_hex: String,
    finalized_slot: String,
    kind: Kind,
    value_hex: String,
    compressed_address_hex: String,
    data_hash_hex: Option<String>,
    tree_key_hex: String,
    queue_key_hex: Option<String>,
    root_hex: Option<String>,
    root_index: Option<u16>,
    verification: &'static str,
}

fn require(condition: bool, message: &str) -> Checked<()> {
    if condition { Ok(()) } else { Err(message.to_owned()) }
}

fn checked<T, E: std::fmt::Display>(value: Result<T, E>) -> Checked<T> {
    value.map_err(|error| error.to_string())
}

fn decimal(value: &str) -> Checked<u64> {
    let number = checked(value.parse::<u64>())?;
    require(number.to_string() == value, "noncanonical decimal")?;
    Ok(number)
}

fn unhex(value: &str, max_bytes: usize) -> Checked<Vec<u8>> {
    require(value.len() % 2 == 0 && value.len() / 2 <= max_bytes, "hex size")?;
    require(value.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)), "hex encoding")?;
    value.as_bytes().chunks_exact(2).map(|pair| {
        let digit = |b: u8| if b <= b'9' { b - b'0' } else { b - b'a' + 10 };
        Ok(digit(pair[0]) * 16 + digit(pair[1]))
    }).collect()
}

fn hex32(value: &str) -> Checked<[u8; 32]> {
    unhex(value, 32)?.try_into().map_err(|_| "expected 32 bytes".to_owned())
}

fn to_hex(value: &[u8]) -> String {
    value.iter().map(|b| format!("{b:02x}")).collect()
}

fn account_bytes(account: &Account) -> Checked<Vec<u8>> {
    hex32(&account.key_hex)?;
    require(hex32(&account.owner_hex)? == ACCOUNT_COMPRESSION_PROGRAM_ID, "compression owner")?;
    require(!account.executable, "executable tree/queue")?;
    let data = unhex(&account.data_hex, MAX_ACCOUNT)?;
    require(data.len() >= 8, "truncated account")?;
    Ok(data)
}

fn validate_batches(batches: &QueueBatches, has_bloom: bool) -> Checked<()> {
    require(batches.num_batches == 2, "batch count")?;
    require(batches.currently_processing_batch_index < 2 && batches.pending_batch_index < 2, "batch index")?;
    require(batches.batch_size > 0 && batches.batch_size <= MAX_ACCOUNT as u64, "batch size")?;
    require(batches.zkp_batch_size > 0 && batches.batch_size % batches.zkp_batch_size == 0, "zkp batch size")?;
    require(batches.bloom_filter_capacity <= (MAX_ACCOUNT as u64) * 8, "bloom size")?;
    for batch in &batches.batches {
        require(if has_bloom { batch.num_iters > 0 && batch.num_iters <= 1024 } else { batch.num_iters == 0 }, "bloom iterations")?;
        require(batch.bloom_filter_capacity == batches.bloom_filter_capacity, "bloom metadata")?;
        require(batch.batch_size == batches.batch_size && batch.zkp_batch_size == batches.zkp_batch_size, "batch dimensions")?;
    }
    require(if has_bloom { batches.bloom_filter_capacity > 0 && batches.bloom_filter_capacity % 8 == 0 } else { batches.bloom_filter_capacity == 0 }, "bloom capacity")?;
    Ok(())
}

fn derive_identity(identity: &Identity) -> Checked<[u8; 32]> {
    require((1..=10).contains(&identity.domain), "current domain")?;
    let program = hex32(&identity.program_id_hex)?;
    let address_tree = hex32(&identity.address_tree_key_hex)?;
    let pda = hex32(&identity.canonical_pda_hex)?;
    require(program != [0; 32] && address_tree != [0; 32] && pda != [0; 32], "zero identity")?;
    let domain_seed = [identity.domain];
    let seed = light_sdk_types::address::v2::derive_address_seed(&[
        b"ameba-spread-v2", b"compressed-state-v1", &domain_seed, &pda,
    ]);
    Ok(light_sdk_types::address::v2::derive_address_from_seed(&seed, &address_tree, &program))
}

fn verify_leaf(
    identity: &Identity,
    leaf: &LeafAccount,
    address: [u8; 32],
    tree: &Pubkey,
    leaf_index: u32,
    expected_hash: [u8; 32],
) -> Checked<String> {
    require(leaf.owner_hex == identity.program_id_hex, "leaf owner")?;
    require(hex32(&leaf.address_hex)? == address, "leaf derived address")?;
    require(decimal(&leaf.lamports)? == 0, "state leaf lamports")?;
    let data = unhex(&leaf.data_hex, 46 + 768)?;
    let lengths = [44usize, 156, 112, 105, 81, 16, 17, 107, 205, 96];
    let compact_length = lengths[usize::from(identity.domain - 1)];
    require(data.len() == 46 + compact_length, "leaf envelope length")?;
    require(data[0] == 1 && data[1] == identity.domain, "leaf schema/domain")?;
    require(data[2..34] == hex32(&identity.canonical_pda_hex)?, "leaf canonical PDA")?;
    let declared = u32::from_le_bytes(data[42..46].try_into().map_err(|_| "leaf length")?);
    require(declared as usize == compact_length, "leaf compact length")?;
    // Same discriminator derivation as light-sdk-macros 0.23.0 LightDiscriminator.
    let type_hash = Sha256::digest(b"CompressedAmebaStateLeaf");
    let discriminator: [u8; 8] = type_hash[..8].try_into().map_err(|_| "discriminator")?;
    require(unhex(&leaf.discriminator_hex, 8)? == discriminator, "leaf discriminator")?;
    // Same SHA256BE body hash as the program's compression.rs::hash_leaf_data.
    let mut data_hash: [u8; 32] = Sha256::digest(&data).into();
    data_hash[0] = 0;
    require(hex32(&leaf.data_hash_hex)? == data_hash, "leaf data hash")?;
    let account = CompressedAccount {
        owner: Pubkey::new_from_array(hex32(&leaf.owner_hex)?),
        lamports: 0,
        address: Some(address),
        data: Some(CompressedAccountData { discriminator, data, data_hash }),
    };
    require(checked(account.hash(tree, &leaf_index, true))? == expected_hash, "full leaf hash")?;
    Ok(to_hex(&data_hash))
}

fn run(raw: &[u8]) -> Checked<Verified> {
    let request: Request = checked(serde_json::from_slice(raw))?;
    require(request.schema == SCHEMA, "schema")?;
    require(decimal(&request.finalized_slot)? >= decimal(&request.minimum_slot)?, "snapshot floor")?;
    hex32(&request.context_binding_hex)?;
    let statement = &request.statement;
    let address_mode = statement.kind == Kind::AddressAbsent;
    let queue_mode = statement.kind == Kind::StateQueue;
    require(request.accounts.len() == if address_mode { 1 } else { 2 }, "account inventory size")?;
    let tree_key = Pubkey::new_from_array(hex32(&statement.tree_key_hex)?);
    let value = hex32(&statement.value_hex)?;
    require(value != [0; 32], "zero value")?;
    let compressed_address = derive_identity(&request.identity)?;
    let data_hash_hex = if address_mode {
        require(request.compressed_account.is_none(), "absence leaf payload")?;
        require(request.identity.address_tree_key_hex == statement.tree_key_hex, "address tree identity")?;
        require(compressed_address == value, "absence derived address")?;
        None
    } else {
        let leaf_index = decimal(statement.leaf_index.as_deref().ok_or("missing leaf index")?)?;
        require(leaf_index <= u32::MAX as u64, "leaf index range")?;
        Some(verify_leaf(&request.identity, request.compressed_account.as_ref().ok_or("missing leaf account")?,
            compressed_address, &tree_key, leaf_index as u32, value)?)
    };
    for (index, account) in request.accounts.iter().enumerate() {
        require(!request.accounts[..index].iter().any(|other| other.key_hex == account.key_hex), "duplicate account")?;
    }
    let tree_account = request.accounts.iter().find(|a| a.key_hex == statement.tree_key_hex).ok_or("missing tree")?;
    let mut tree_data = account_bytes(tree_account)?;
    let tree_len = tree_data.len();
    // address_from_bytes omits this check in the pinned crate, so perform it here.
    require(&tree_data[..8] == b"BatchMta", "tree discriminator")?;
    let mut tree = if address_mode {
        checked(BatchedMerkleTreeAccount::address_from_bytes(&mut tree_data, &tree_key))?
    } else {
        checked(BatchedMerkleTreeAccount::state_from_bytes(&mut tree_data, &tree_key))?
    };
    let metadata = tree.get_metadata();
    validate_batches(&metadata.queue_batches, true)?;
    require(metadata.height == if address_mode { 40 } else { 32 }, "tree height")?;
    require(metadata.capacity == 1u64 << metadata.height, "tree capacity")?;
    require(metadata.next_index <= metadata.capacity, "tree insertion cursor")?;
    require(tree_len == checked(metadata.get_account_size())?, "tree account length")?;
    require(tree.root_history.capacity() == metadata.root_history_capacity as usize && tree.root_history.len() > 0, "root history metadata")?;

    if address_mode {
        require(statement.queue_key_hex.is_none() && statement.leaf_index.is_none(), "address-only fields")?;
    } else {
        let leaf_index = decimal(statement.leaf_index.as_deref().ok_or("missing leaf index")?)?;
        require(leaf_index <= u32::MAX as u64, "leaf index range")?;
        let queue_key_hex = statement.queue_key_hex.as_ref().ok_or("missing queue key")?;
        let queue_key = Pubkey::new_from_array(hex32(queue_key_hex)?);
        require(queue_key != tree_key && tree.get_associated_queue() == &queue_key, "tree queue binding")?;
        let queue_account = request.accounts.iter().find(|a| &a.key_hex == queue_key_hex).ok_or("missing queue")?;
        let mut queue_data = account_bytes(queue_account)?;
        let queue_len = queue_data.len();
        let mut queue = checked(BatchedQueueAccount::output_from_bytes(&mut queue_data))?;
        checked(queue.check_is_associated(&tree_key))?;
        let queue_metadata = queue.get_metadata();
        validate_batches(&queue_metadata.batch_metadata, false)?;
        require(queue_metadata.tree_capacity == 1u64 << 32, "queue capacity")?;
        require(queue_len == get_output_queue_account_size(queue_metadata.batch_metadata.batch_size, queue_metadata.batch_metadata.zkp_batch_size), "queue account length")?;
        if queue_mode {
            require(checked(queue.prove_inclusion_by_index(leaf_index, &value))?, "leaf outside current queue")?;
        } else {
            require(leaf_index < tree.get_metadata().next_index, "leaf not inserted into tree")?;
            // A retained output-queue slot also records spends by zeroing its value.
            // An out-of-window index returns false; a retained mismatched/zero value errors.
            checked(queue.prove_inclusion_by_index(leaf_index, &value))?;
        }
    }

    checked(tree.check_input_queue_non_inclusion(&value))?;
    if queue_mode {
        require(statement.root_hex.is_none() && statement.root_index.is_none() && statement.proof_hex.is_none(), "queue proof fields")?;
    } else {
        let root = hex32(statement.root_hex.as_deref().ok_or("missing root")?)?;
        let root_index = statement.root_index.ok_or("missing root index")?;
        require(root != [0; 32] && tree.get_root_index() == u32::from(root_index), "noncurrent root index")?;
        require(tree.get_root() == Some(root) && tree.get_root_by_index(usize::from(root_index)) == Some(&root), "root mismatch")?;
        let proof_bytes = unhex(statement.proof_hex.as_deref().ok_or("missing proof")?, 128)?;
        require(proof_bytes.len() == 128, "proof length")?;
        let proof = CompressedProof {
            a: proof_bytes[..32].try_into().map_err(|_| "proof a")?,
            b: proof_bytes[32..96].try_into().map_err(|_| "proof b")?,
            c: proof_bytes[96..].try_into().map_err(|_| "proof c")?,
        };
        let public_input = checked(create_two_inputs_hash_chain(&[root], &[value]))?;
        let key = checked(select_verifying_key(if address_mode { 0 } else { 1 }, if address_mode { 1 } else { 0 }))?;
        checked(verify::<1>(&[public_input], &proof, key))?;
    }

    Ok(Verified {
        schema: SCHEMA,
        request_sha256: to_hex(&Sha256::digest(raw)),
        context_binding_hex: request.context_binding_hex,
        finalized_slot: request.finalized_slot,
        kind: statement.kind,
        value_hex: statement.value_hex.clone(),
        compressed_address_hex: to_hex(&compressed_address),
        data_hash_hex,
        tree_key_hex: statement.tree_key_hex.clone(),
        queue_key_hex: statement.queue_key_hex.clone(),
        root_hex: statement.root_hex.clone(),
        root_index: statement.root_index,
        verification: if queue_mode { "queue_inclusion_and_bloom" } else { "groth16_current_root_and_bloom" },
    })
}

fn main() {
    // Malformed dependency-decoder inputs may panic. Never emit a success result.
    let result = std::panic::catch_unwind(|| -> Checked<()> {
        let mut raw = Vec::new();
        checked(std::io::stdin().lock().take((MAX_INPUT + 1) as u64).read_to_end(&mut raw))?;
        require(raw.len() <= MAX_INPUT, "input limit")?;
        let verified = run(&raw)?;
        let encoded = checked(serde_json::to_vec(&verified))?;
        checked(std::io::stdout().lock().write_all(&encoded))
    });
    if !matches!(result, Ok(Ok(()))) {
        eprintln!("compressed evidence verification failed");
        std::process::exit(1);
    }
}
